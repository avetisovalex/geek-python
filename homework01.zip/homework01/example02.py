userTime = int(input("type amount of seconds >>>"))
seconds = userTime % 60
minutes = (userTime // 60) % 60
hours = (userTime // 60) // 60
print(f"{hours}:{minutes}:{seconds}")
while True:
    try:
        userInput = int(input("input positive integer number >>>"))
        break
    except ValueError:
        print("Oops! It doesn't look like a number!")
max = 0
while userInput > 0:
    if (userInput % 10) > max:
        max = userInput % 10
    userInput = userInput // 10
print(f"max digit = {max}")

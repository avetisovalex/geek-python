firstInt = 10
secondInt = int(input("type second number >>>"))
firstStr = input("type first string >>>")
print(firstInt, secondInt, firstStr)
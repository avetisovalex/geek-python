while True:
    try:
        earnings = int(input("input earnings of the company >>>"))
        expenses = int(input("input expenses of the company >>>"))
        break
    except ValueError:
        print("Oops! It doesn't look like a number!")
if earnings > expenses:
    print("profit")
    profitability = (earnings - expenses) / earnings
    amountOfEmployees = int(input("input amount of employees >>>"))
    profitPerEmployee = profitability / amountOfEmployees
    print(f"profitability = {profitability}, profitPerEmployee= {profitPerEmployee}")
else:
    print("loss")

while True:
    try:
        a = int(input("1st result was >>>"))
        b = int(input("target result would be >>>"))
        break
    except ValueError:
        print("Oops! It doesn't look like a number!")
days = 1
while a <= b:
    a = a + 0.1 * a
    days = days + 1
print (days)
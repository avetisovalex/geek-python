while True:
    try:
        userInput = input("input number >>>")
        n1 = userInput
        n2 = userInput + n1
        n3 = n1 + n2
        break
    except ValueError:
        print("Oops! It doesn't look like a number!")
result = int(n1) + int(n2) + int(n3)

print(result)
